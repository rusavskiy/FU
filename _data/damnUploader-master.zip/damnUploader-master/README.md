damnUploader
============

jQuery file upload plugin (supports FormData in modern browsers, fallback to default form uploading in older)